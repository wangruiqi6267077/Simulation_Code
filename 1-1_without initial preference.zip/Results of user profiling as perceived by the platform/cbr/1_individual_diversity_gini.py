# 个体多样性gini系数分析，使用表格userprofile
import pandas as pd
import numpy as np
import matplotlib.pyplot as pl

def Gini(topic_weights_list):
    topic_weights=topic_weights_list
    cum_weights = np.cumsum(sorted(np.append(topic_weights, 0)))
    sum_weights = cum_weights[-1]
    xarray1 = np.array(range(0, len(cum_weights))) / np.float(len(cum_weights) - 1)
    # upper = xarray1
    yarray1 = cum_weights / sum_weights
    B = np.trapz(yarray1, x=xarray1)
    A = 0.5 - B
    G = A / (A + B)
    return G
def pic(list):
    xarray = [i for i in range(1, len(list) + 1, 1)]
    yarray = list
    pl.plot(xarray, yarray, c='red')
    # pl.show()
def average_users_gini_pic(ginilist):
    # 将所有用户每天的平均gini随day变化画出来
    avelist=[]
    for day in range(0,len(ginilist[0])):
        daygini=0
        for usergini in ginilist:
            daygini+=usergini[day]
        daygini=daygini/50
        avelist.append(daygini)
        # print(daygini)
    pic(avelist)
    return avelist
def muti_case_in_one_case(*ginilists):
    xarray=[i for i in range(1, len(ginilists[0]) + 1, 1)]
    varnames = locals()
    for i in range(len(ginilists)):
        varnames['array' + str(i)] = ginilists[i]
        pl.plot(xarray,varnames['array' + str(i)],label='array' + str(i))
    pl.legend()
    pl.xlabel('Day')
    pl.ylabel('Average Individual  Gini Coefficient')
    pl.show()


def start_and_end_gini_distribution(ginilist):
    # 分析50个用户初始和最后gini系数分布，并用直方图可视化
    startgini=[]
    endgini=[]
    for list in ginilist:
        startgini.append(list[0])
        endgini.append(list[-1])
    x=0
    y=x+0.1
    startcount=[]
    while(x<=0.9):
        count=0
        for usergini in startgini:
            if usergini>x and usergini<=y:
                count+=1
        startcount.append(count)
        x+=0.1
        y=x+0.1

    x = 0
    y = x + 0.1
    endcount = []
    while (x <= 0.9):
        count = 0
        for usergini in endgini:
            if usergini > x and usergini <= y:
                count += 1
        endcount.append(count)
        x += 0.1
        y = x + 0.1


    n = 10
    startcount = tuple(startcount)
    endcount=tuple(endcount)
    ind = np.arange(n)
    width = 0.5
    fig, ax = pl.subplots()
    starts = ax.bar(ind, startcount, width, edgecolor='black')  # ,color='#ffad00')
    ends= ax.bar(ind, endcount, width, edgecolor='black')
    ax.set_xticks(ind)
    # ax.set_yticks([0, 20, 40, 60, 80, 100, 120, 140, 160])
    ax.set_xticklabels(
        ('0-0.1', '0.1-0.2', '0.2-0.3', '0.3-0.4', '0.4-0.5', '0.5-0.6', '0.6-0.7', '0.7-0.8', '0.8-0.9', '0.9-1'))
    # ax.tick_params(axis='x',labelsize=8)
    def autolabel(rects):
        # attach some text labels
        for rect in rects:
            height = rect.get_height()
            hcap = str(height)
            ax.text(rect.get_x() + rect.get_width() / 2., height, hcap, ha='center', va='bottom')
    autolabel(starts)
    autolabel(ends)
    pl.show()
def get_users_ginilist_or_user_ginilist(df):
    #这个函数是从dataframe中得到每个用户每天的gini系数列表，或者得到每天的所有用户平均gini系数列表
    ginilist=[]
    for userid in range(1,51):
        dfi=df.loc[df['userid']==userid]
        # print(dfi)
        ginilisti=[]
        for index,row in dfi.iterrows():
            uservector=[]
            for i in range(10):
                uservector.append(row['topic'+str(i)])
            ginirow=Gini(uservector)
            ginilisti.append(ginirow)
        ginilist.append(ginilisti)
    # pic(ginilisti)#将每个用户的gini系数随时间变化都画出来
    return ginilist#返回的是所有用户所有天的gini系数，为列表的列表


df1=pd.read_csv('userprofile_datas_(1, 0, 0).csv')
ginilist1=get_users_ginilist_or_user_ginilist(df1)
averagelist1=average_users_gini_pic(ginilist1)

df2=pd.read_csv('userprofile_datas_(0, 1, 0).csv')
ginilist2=get_users_ginilist_or_user_ginilist(df2)
averagelist2=average_users_gini_pic(ginilist2)

df3=pd.read_csv('userprofile_datas_(0, 0, 1).csv')
ginilist3=get_users_ginilist_or_user_ginilist(df3)
averagelist3=average_users_gini_pic(ginilist3)
#
# df4=pd.read_csv('userprofile_datas_(0.3, 0.5, 0.2).csv')
# ginilist4=get_users_ginilist_or_user_ginilist(df4)
# averagelist4=average_users_gini_pic(ginilist4)
#
# df5=pd.read_csv('userprofile_datas_(0.2, 0.5, 0.3).csv')
# ginilist5=get_users_ginilist_or_user_ginilist(df5)
# averagelist5=average_users_gini_pic(ginilist5)
#
# df6=pd.read_csv('userprofile_datas_(0.3, 0.2, 0.5).csv')
# ginilist6=get_users_ginilist_or_user_ginilist(df6)
# averagelist6=average_users_gini_pic(ginilist6)
#
# df7=pd.read_csv('userprofile_datas_(0.2, 0.3, 0.5).csv')
# ginilist7=get_users_ginilist_or_user_ginilist(df7)
# averagelist7=average_users_gini_pic(ginilist7)

muti_case_in_one_case(averagelist1,averagelist2,averagelist3)#, averagelist4,averagelist5,averagelist6,averagelist7)


# average_users_gini_pic(ginilist1)

# start_and_end_gini_distribution(ginilist)
