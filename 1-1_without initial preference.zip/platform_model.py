# 每天产生50篇新闻，并在这30篇新闻中有三篇热点新闻
from random import *
from math import *
import pandas as pd

# 参数：新闻个数
number_of_news=50

# 产生服从幂律分布的50个新闻的数值列表
def randht(n, *varargin):
    # n是个数，然后把除n以外的其他参数全部放到列表varargin里边
    Type = '';
    xmin = 1;
    alpha = 2.5;
    beta = 1;
    Lambda = 1;
    mu = 1;
    sigma = 1;

    # parse command-line parameters; trap for bad input
    i = 0;
    while i < len(varargin):
        argok = 1;
        if type(varargin[i]) == str:
            if varargin[i] == 'xmin':
                xmin = varargin[i + 1]
                i = i + 1
            elif varargin[i] == 'powerlaw':
                Type = 'PL'
                alpha = varargin[i + 1]
                i = i + 1
            elif varargin[i] == 'cutoff':
                Type = 'PC';
                alpha = varargin[i + 1]
                Lambda = varargin[i + 2]
                i = i + 2
            elif varargin[i] == 'exponential':
                Type = 'EX'
                Lambda = varargin[i + 1]
                i = i + 1
            elif varargin[i] == 'lognormal':
                Type = 'LN';
                mu = varargin[i + 1]
                sigma = varargin[i + 2]
                i = i + 2
            elif varargin[i] == 'stretched':
                Type = 'ST'
                Lambda = varargin[i + 1]
                beta = varargin[i + 2]
                i = i + 2
            else:
                argok = 0

        if not argok:
            print
            '(RANDHT) Ignoring invalid argument #', i + 1

        i = i + 1

    if n < 1:
        print
        '(RANDHT) Error: invalid ''n'' argument; using default.\n'
        n = 10000;

    if xmin < 1:
        print
        '(RANDHT) Error: invalid ''xmin'' argument; using default.\n'
        xmin = 1;

    x = []
    if Type == 'EX':
        x = []
        for i in range(n):
            x.append(xmin - (1. / Lambda) * log(1 - random()))
    elif Type == 'LN':
        y = []
        for i in range(10 * n):
            y.append(exp(mu + sigma * normalvariate(0, 1)))

        while True:
            y = filter(lambda X: X >= xmin, y)
            q = len(y) - n;
            if q == 0: break

            if q > 0:
                r = range(len(y));
                shuffle(r)
                ytemp = []
                for j in range(len(y)):
                    if j not in r[0:q]:
                        ytemp.append(y[j])
                y = ytemp
                break
            if (q < 0):
                for j in range(10 * n):
                    y.append(exp(mu + sigma * normalvariate(0, 1)))

        x = y

    elif Type == 'ST':
        x = []
        for i in range(n):
            x.append(pow(pow(xmin, beta) - (1. / Lambda) * log(1. - random()), (1. / beta)))
    elif Type == 'PC':

        x = []
        y = []
        for i in range(10 * n):
            y.append(xmin - (1. / Lambda) * log(1. - random()))
        while True:
            ytemp = []
            for i in range(10 * n):
                if random() < pow(y[i] / float(xmin), -alpha): ytemp.append(y[i])
            y = ytemp
            x = x + y
            q = len(x) - n
            if q == 0: break;

            if (q > 0):
                r = range(len(x))
                shuffle(r)

                xtemp = []
                for j in range(len(x)):
                    if j not in r[0:q]:
                        xtemp.append(x[j])
                x = xtemp
                break;

            if (q < 0):
                y = []
                for j in range(10 * n):
                    y.append(xmin - (1. / Lambda) * log(1. - random()))


    else:
        x = []
        for i in range(n):
            x.append(xmin * pow(1. - random(), -1. / (alpha - 1.)))
    return x


# 产生服从幂律分布的50个新闻hot值列表，且顺序混乱
def get_hot():
    hot_list = randht(50,'xmin',0,'powerlaw',2,5)
    sum=0
    for i in hot_list:
        sum+=i
    for i in range(len(hot_list)):
        hot_list[i]=hot_list[i]/sum
    return hot_list
# 下边函数得到随机列表，但是没有归一化
def random_list(start,stop,length):
    if length>=0:
        length=int(length)
    start, stop = (int(start), int(stop)) if start <= stop else (int(stop),int(start))
    random_list = []
    for i in range(length):
        random_list.append(randint(start, stop))
    return random_list


# 下边函数得到随机的新闻主题向量
def get_new():
    new=randht(10,'xmin',0,'powerlaw',1.02)#跟实际数据对比后，幂律分布得出新闻主题分布更合适
    # new=random_list(0,10,10)#这是原来得到的随机的方式，跟实际数据的拟合度很低
    sum=0
    for topic in new:
        sum+=topic
    for i in range(len(new)):
        new[i]=new[i]/sum
    return new

# 得到一天的新闻集合，每篇新闻都存有新闻向量和热度值,每天50篇，并用字典保存之
def get_day_news(day):
    day_news={}
    hotlist=get_hot()
    for i in range(1,number_of_news+1):
        newid=str(day)+'-'+str(i)
        newinfordic={}
        newvector=get_new()
        newhot=hotlist.pop()
        newinfordic['newvector']=newvector
        newinfordic['newhot']=newhot
        day_news[newid]=newinfordic
    return day_news


daynews=get_day_news(0)
print(daynews)
dfnews=pd.DataFrame({'newid':[],
                     'topic0':[],
                     'topic1':[],
                     'topic2':[],
                     'topic3':[],
                     'topic4':[],
                     'topic5': [],
                     'topic6': [],
                     'topic7': [],
                     'topic8': [],
                     'topic9': [],
                     'hot':[]
                     })
for newid, newinfor in daynews.items():
    temporarylist = []
    temporarylist = [newid, newinfor['newvector'][0], newinfor['newvector'][1], newinfor['newvector'][2]
        , newinfor['newvector'][3], newinfor['newvector'][4], newinfor['newvector'][5], newinfor['newvector'][6]
        , newinfor['newvector'][7], newinfor['newvector'][8], newinfor['newvector'][9], newinfor['newhot']]
    dfnew = pd.DataFrame(temporarylist).T
    dfnew.columns = dfnews.columns
    dfnews = dfnews.append(dfnew)
dfnews.to_csv('simulation_oneday_distribtuion1_01.csv')
