# 以两种方式。每次随机产生20个初始偏好的用户，并保存在字典中
# 第一种方式是随机产生有初始偏好的用户
# 第二种方式是产生初始偏好全部为0.1的初始化用户
from random import *

# 参数：用户个数
num_of_users=50

def randhtt(n, *varargin):
    # n是个数，然后把除n以外的其他参数全部放到列表varargin里边
    Type = '';
    xmin = 1;
    alpha = 2.5;
    beta = 1;
    Lambda = 1;
    mu = 1;
    sigma = 1;

    # parse command-line parameters; trap for bad input
    i = 0;
    while i < len(varargin):
        argok = 1;
        if type(varargin[i]) == str:
            if varargin[i] == 'xmin':
                xmin = varargin[i + 1]
                i = i + 1
            elif varargin[i] == 'powerlaw':
                Type = 'PL'
                alpha = varargin[i + 1]
                i = i + 1
            elif varargin[i] == 'cutoff':
                Type = 'PC';
                alpha = varargin[i + 1]
                Lambda = varargin[i + 2]
                i = i + 2
            elif varargin[i] == 'exponential':
                Type = 'EX'
                Lambda = varargin[i + 1]
                i = i + 1
            elif varargin[i] == 'lognormal':
                Type = 'LN';
                mu = varargin[i + 1]
                sigma = varargin[i + 2]
                i = i + 2
            elif varargin[i] == 'stretched':
                Type = 'ST'
                Lambda = varargin[i + 1]
                beta = varargin[i + 2]
                i = i + 2
            else:
                argok = 0

        if not argok:
            print
            '(RANDHT) Ignoring invalid argument #', i + 1

        i = i + 1

    if n < 1:
        print
        '(RANDHT) Error: invalid ''n'' argument; using default.\n'
        n = 10000;

    if xmin < 1:
        print
        '(RANDHT) Error: invalid ''xmin'' argument; using default.\n'
        xmin = 1;

    x = []
    if Type == 'EX':
        x = []
        for i in range(n):
            x.append(xmin - (1. / Lambda) * log(1 - random()))
    elif Type == 'LN':
        y = []
        for i in range(10 * n):
            y.append(exp(mu + sigma * normalvariate(0, 1)))

        while True:
            y = filter(lambda X: X >= xmin, y)
            q = len(y) - n;
            if q == 0: break

            if q > 0:
                r = range(len(y));
                shuffle(r)
                ytemp = []
                for j in range(len(y)):
                    if j not in r[0:q]:
                        ytemp.append(y[j])
                y = ytemp
                break
            if (q < 0):
                for j in range(10 * n):
                    y.append(exp(mu + sigma * normalvariate(0, 1)))

        x = y

    elif Type == 'ST':
        x = []
        for i in range(n):
            x.append(pow(pow(xmin, beta) - (1. / Lambda) * log(1. - random()), (1. / beta)))
    elif Type == 'PC':

        x = []
        y = []
        for i in range(10 * n):
            y.append(xmin - (1. / Lambda) * log(1. - random()))
        while True:
            ytemp = []
            for i in range(10 * n):
                if random() < pow(y[i] / float(xmin), -alpha): ytemp.append(y[i])
            y = ytemp
            x = x + y
            q = len(x) - n
            if q == 0: break;

            if (q > 0):
                r = range(len(x))
                shuffle(r)

                xtemp = []
                for j in range(len(x)):
                    if j not in r[0:q]:
                        xtemp.append(x[j])
                x = xtemp
                break;

            if (q < 0):
                y = []
                for j in range(10 * n):
                    y.append(xmin - (1. / Lambda) * log(1. - random()))


    else:
        x = []
        for i in range(n):
            x.append(xmin * pow(1. - random(), -1. / (alpha - 1.)))
    return x


def random_list(start,stop,length):
    if length>=0:
        length=int(length)
    start, stop = (int(start), int(stop)) if start <= stop else (int(stop),int(start))
    random_list = []
    for i in range(length):
        random_list.append(random.randint(start, stop))
    return random_list

# 得到单个用户的随机初始偏好列表
def get_user():
    # user=random_list(0,10,10)
    user = randhtt(10, 'xmin', 0, 'powerlaw', 1.5)
    # print(user)
    sum=0
    for topic in user:
        sum+=topic
    # print(sum)
    for i in range(len(user)):
        user[i]=user[i]/sum
    return user

# 得到用户组，包含20个用户
def get_users():
    users={}
    for i in range(1,num_of_users+1):
        userid=str(i)
        uservector=get_user()
        users[userid]=uservector
    return users

# 下边这个是得到初始向量全部为0.1的用户
def get_users2():
    users={}
    for i in range(1,num_of_users+1):
        userid=str(i)
        uservector=[0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1]
        users[userid]=uservector
    return users
# print(get_users())
# print(get_users2())