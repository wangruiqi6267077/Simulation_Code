# NOTE:news_dic中的新闻id是字符串格式，其余是int，如readed_list,pop_list, recommended_list
import user_model as um
import platform_model as pm
import hotnews_and_selfchoose_model as hm
import recommendation_model as rm
import choose_model as cm
import pandas as pd
import random
import feedback_modele as fm

# 1、构建十个初始用户字典

cases_list=[(1,0,0),(0,1,0),(0,0,1),(0.3,0.7,0),(0.5,0.5,0),(0.7,0.3,0),(0.3,0,0.7),(0.5,0,0.5),(0.7,0,0.3),(0,0.5,0.5),(0,0.3,0.7),(0,0.7,0.3),
            (0.33, 0.33, 0.33),(0.5,0.3,0.2),(0.5,0.2,0.3),(0.3,0.2,0.5),(0.2,0.3,0.5),(0.3,0.5,0.2),(0.2,0.5,0.3)]
for case in cases_list:
    # print('ready case '+str(case))
    user_dic=um.get_users()
    fake_user_dic=um.get_users2()
    alpha=case[0]
    beta=case[1]
    gama=case[2]
    print(alpha,beta,gama)
# user_dic=um.get_users2()
    df=pd.DataFrame({'userid':[],
                     'newid':[],
                     'day':[],
                     'topic0':[],
                     'topic1':[],
                     'topic2':[],
                     'topic3':[],
                     'topic4':[],
                     'topic5': [],
                     'topic6': [],
                     'topic7': [],
                     'topic8': [],
                     'topic9': [],
                  })
    dfnews=pd.DataFrame({'newid':[],
                         'topic0':[],
                         'topic1':[],
                         'topic2':[],
                         'topic3':[],
                         'topic4':[],
                         'topic5': [],
                         'topic6': [],
                         'topic7': [],
                         'topic8': [],
                         'topic9': [],
                         'hot':[]
                         })
    dfuserprofile=pd.DataFrame({'userid':[],
                                'day':[],
                                'topic0':[],
                                'topic1':[],
                                'topic2':[],
                                'topic3':[],
                                'topic4':[],
                                'topic5': [],
                                'topic6': [],
                                'topic7': [],
                                'topic8': [],
                                'topic9': []})
    # print(dfuserprofile)
    # 先把50个用户初始画像都给放进去
    for userid,uservector in user_dic.items():
        # 先把最初的画像记录到表格当中，这里记录的是真实的画像
        t_list = [userid, -1,uservector[0],uservector[1], uservector[2] , uservector[3], uservector[4],
                         uservector[5], uservector[6], uservector[7], uservector[8], uservector[9]]
        dfuserprofile_i = pd.DataFrame(t_list).T
        dfuserprofile_i.columns = dfuserprofile.columns
        dfuserprofile = dfuserprofile.append(dfuserprofile_i)#这里应该是真实的用户画像的记录，因为我们最后测算的是真实画像的变化，平台以为的画像只在推荐时使用

    # print('dfs has been done')
    # 2、构建100天实验期限
    for day in range(0,100,1):
        # 获得当日新闻字典和热点新闻列表
        news_dic=pm.get_day_news(day)
        # 新闻字典中包含新闻id，和新闻主题向量、hot值，后两个又储存在了一个字典当中
        pop_news_list=hm.get_hotnews_list(news_dic)
        # 获取当日流行新闻列表
        selfchoose_dic=hm.get_selfchoose_dic(news_dic)
        # 获取自选列表字典，并且存在字典中
        # 构建一个当天的用户浏览记录字典，以应用在协同过滤推荐中
        all_user_read_record={}
        # 将当日新闻存放在dfnews中
        # print('ready to simulation')
        for newid,newinfor in news_dic.items():
            temporarylist=[]
            temporarylist=[newid,newinfor['newvector'][0],newinfor['newvector'][1],newinfor['newvector'][2]
                , newinfor['newvector'][3],newinfor['newvector'][4],newinfor['newvector'][5],newinfor['newvector'][6]
                , newinfor['newvector'][7],newinfor['newvector'][8],newinfor['newvector'][9],newinfor['newhot']]
            dfnew = pd.DataFrame(temporarylist).T
            dfnew.columns = dfnews.columns
            dfnews = dfnews.append(dfnew)
        # 下面对每个用户的浏览过程模拟
        # print('当天的新闻已经采集到表格中')
        for userid,uservector in fake_user_dic.items():

            iter_num=random.randint(5,10)

            # recommendlist=rm.cbr(uservector,news_dic)#这个地方的uservector是平台认为的uservector

            recommendlist=rm.cfr(uservector,user_dic,all_user_read_record)
            if len(recommendlist)<10:#如果用户是最开始，此时往往由于还没有相似用户，所以alluserreadrecord可能为空，此时换用基于内容的推荐系统
                recommendlist=rm.cbr(uservector,news_dic)

            readed_list=cm.choose(alpha,beta,gama,recommendlist,pop_news_list,selfchoose_dic,user_dic[userid],news_dic,iter_num)
            # 将这个记录存储进浏览记录字典中，用于协同过滤推荐
            # print('用户已经阅读了')
            all_user_read_record[userid]=readed_list
            # 接下来更新用户画像
            uservector_new=fm.userupdata(user_dic[userid],readed_list,news_dic)
            fake_uservector_new=fm.userupdata(uservector,readed_list,news_dic)

            user_dic[userid]=uservector_new
            fake_user_dic[userid]=fake_uservector_new
            # print('用户画像更新了')
            result_list=[]
            for readednew in readed_list:
                result_list=[userid, readednew, day, news_dic[readednew]['newvector'][0], news_dic[readednew]['newvector'][1],
                             news_dic[readednew]['newvector'][2], news_dic[readednew]['newvector'][3], news_dic[readednew]['newvector'][4],
                             news_dic[readednew]['newvector'][5], news_dic[readednew]['newvector'][6], news_dic[readednew]['newvector'][7],
                             news_dic[readednew]['newvector'][8], news_dic[readednew]['newvector'][9] ]
                dfi = pd.DataFrame(result_list).T
                dfi.columns = df.columns
                df = df.append(dfi)
        for userid, uservector in user_dic.items():
            temporarylist = []
            temporarylist = [userid, day, uservector[0], uservector[1], uservector[2]
                , uservector[3], uservector[4], uservector[5], uservector[6]
                , uservector[7], uservector[8], uservector[9]]
            dfuserprofile_i = pd.DataFrame(temporarylist).T
            dfuserprofile_i.columns = dfuserprofile.columns
            dfuserprofile = dfuserprofile.append(dfuserprofile_i)
        print('day ' + str(day) + ' has been done!')
        # print(dfuserprofile)
    print('case'+str(case)+'has been done!')
    # print(all_user_read_record)
    # print(dfnews)
    # print(df)
    # print(dfuserprofile)
    dfnews.to_csv('news_datas_'+str(case)+'.csv')
    df.to_csv('users_news_datas_'+str(case)+'.csv')
    dfuserprofile.to_csv('userprofile_datas_'+str(case)+'.csv')

