# 整体多样性gini系数分析，使用表格users_news_datas
import pandas as pd
import numpy as np
import matplotlib.pyplot as pl

def Gini(topic_weights_list):
    topic_weights=topic_weights_list
    cum_weights = np.cumsum(sorted(np.append(topic_weights, 0)))
    sum_weights = cum_weights[-1]
    xarray1 = np.array(range(0, len(cum_weights))) / np.float(len(cum_weights) - 1)
    # upper = xarray1
    yarray1 = cum_weights / sum_weights
    B = np.trapz(yarray1, x=xarray1)
    A = 0.5 - B
    G = A / (A + B)
    return 1-G

def pic(list):
    xarray = [i for i in range(1, len(resultlist) + 1, 1)]
    yarray = list
    pl.plot(xarray, yarray, c='red')
    # pl.show()

def muti_case_in_one_pic(*ginilists):
    xarray=[i for i in range(1, len(ginilists[0]) + 1, 1)]
    varnames = locals()
    for i in range(len(ginilists)):
        varnames['array' + str(i)] = ginilists[i]
        pl.plot(xarray,varnames['array' + str(i)],label='array' + str(i))
    pl.legend()
    pl.xlabel('Day')
    pl.ylabel('Aggregate Gini Coefficient')
    pl.show()

def get_agg_gini(df):
    grouped=df.groupby(df['day'])
    dfnew=grouped.sum()/grouped.count()
    whole_gini_list=[]
    for i ,row in dfnew.iterrows():
        list=[]
        for j in range(10):
            list.append(row['topic'+str(j)])
        whole_gini_list.append(list)#形成列表的列表，内部列表是某一天的topic列表
    # print(whole_gini_list)
    resultlist=[]
    i=1
    for daylist in whole_gini_list:
        if i%2==0:#调节可是化曲线的密度，每个点画一次还是每两个点画一次
            daygini=Gini(daylist)
            print(daygini)
            resultlist.append(daygini)
            i+=1
        else:
            i+=1
    return resultlist#返回该user_news文件中形成的整体多样性gini随时的列表
print('______________仅推荐____________________')
df1=pd.read_csv('users_news_datas_(1, 0, 0).csv')
aggginilist1=get_agg_gini(df1)
for i in aggginilist1:
    print(i)
print('______________热点____________________')
df2=pd.read_csv('users_news_datas_(0, 1, 0).csv')
aggginilist2=get_agg_gini(df2)
for i in aggginilist2:
    print(i)
print('______________仅自选____________________')
df3=pd.read_csv('users_news_datas_(0, 0, 1).csv')
aggginilist3=get_agg_gini(df3)
for i in aggginilist3:
    print(i)


muti_case_in_one_pic(aggginilist1,aggginilist2,aggginilist3)#,aggginilist4,aggginilist5,aggginilist6,aggginilist7)