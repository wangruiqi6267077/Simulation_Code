# 输入为推荐列表和自选列表，输出为选择看哪个文章,即文章id，以及其vector
import math
import numpy as np
import random


#
# alpha=0.33
# beta=0.33
# gama=0.33


def random_pick(some_list,probabilities):
    # 该函数用来根据概率抽样
    x=random.uniform(0,1)
    cumulative_probability=0.0
    for itemx,item_probability in zip(some_list,probabilities):
        cumulative_probability+=item_probability
        if x < cumulative_probability:
            break
    return itemx

def vij(uservector,newvector):
    # 两个向量之间的距离v_ij=similarity_ij
    k=1
    uservector=np.array(uservector)
    newvector=np.array(newvector)
    distanceij = np.linalg.norm(uservector - newvector)
    vij=-k*math.log(distanceij)
    return vij
def vij_hot(hot):
    # 两个向量之间的距离v_ij=similarity_ij
    k=1#注意这个地方k的取值，如果k太大，说明只喜欢热点值，对于热点值小的新闻，他看的概率就会非常非常小，之后就仿佛进入死循环！
    vij=-k*math.log(hot)
    return vij
def vij_selfchoose(uservector,newvector):
    # 两个向量之间的距离v_ij=similarity_ij
    k=1
    uservector=np.array(uservector)
    newvector=np.array(newvector)
    distanceij = np.linalg.norm(uservector - newvector)
    vij=-k*math.log(distanceij)
    return vij


def choose(alpha,beta,gama,recommendedlist,hotlist,selfchoosedic,uservector,newsdic,iternum):
    x=int(iternum*alpha+0.5)
    y=int(iternum*beta+0.5)
    z=int(iternum*gama+0.5)
    readedlist=[]

    # 下边是推荐中选择
    utilities_x = {}
    for newid in recommendedlist:
            newvector = newsdic[newid]['newvector']
            new_utility = math.exp(vij(uservector, newvector))
            utilities_x[newid] = new_utility
    # 计算所有新闻效度的和
    utilitysum = 0
    for value in utilities_x.values():
        utilitysum += value
    probabilities = {}
    for newid, utility in utilities_x.items():
        probability = utility / utilitysum
        probabilities[newid] = probability
    probabilities = sorted(probabilities.items(), key=lambda x: x[1])
    choose_new_list = []
    probability_list = []
    for i in probabilities:
        choose_new_list.append(i[0])
        probability_list.append(i[1])
    # print(choose_new_list)
    # print(probability_list)
    # 上边两行打印不要删，到时候可以看看每个推荐以及选择概率
    readedlist_x=[]
    while (len(readedlist_x)<x):
        readed_new=random_pick(choose_new_list, probability_list)
        if readed_new not in readedlist:
            readedlist_x.append(readed_new)
            readedlist.append(readed_new)
    # print('readedlist_x:')
    # print(readedlist_x)
        # if len(readedlist_x)>=x:
        #     break



#    从热点中选择
    utilities_y = {}
    for newid in hotlist:
        newhot = newsdic[newid]['newhot']
        new_utility = math.exp(vij_hot(newhot))
        utilities_y[newid] = new_utility
    # 计算所有新闻效度的和
    utilitysum = 0
    for value in utilities_y.values():
        utilitysum += value
    probabilities = {}
    for newid, utility in utilities_y.items():
        probability = utility / utilitysum
        probabilities[newid] = probability
    probabilities = sorted(probabilities.items(), key=lambda x: x[1])
    choose_new_list = []
    probability_list = []
    for i in probabilities:
        choose_new_list.append(i[0])
        probability_list.append(i[1])
    # print(choose_new_list)
    # print(probability_list[0])
    # 上边两行打印不要删，到时候可以看看每个推荐以及选择概率
    readedlist_y = []
    while (len(readedlist_y)<y):
        readed_new = random_pick(choose_new_list, probability_list)
        if readed_new not in readedlist:
            # print("!")
            readedlist_y.append(readed_new)
            readedlist.append(readed_new)
    # print('readedlist_y:')
    # print(readedlist_y)
        # if len(readedlist_y) >= y:
        #     break


#    接下来是自选列表中选择
    selftopics=[]
    topicweights=[]
    for n in range(0,10):
        if uservector[n]>=0.15:
            selftopics.append('topic'+str(n))
            topicweights.append(uservector[n])
    if len(selftopics)==0:
        n=uservector.index(max(uservector))
        selftopics.append('topic'+str(n))
        topicweights.append(1)
    # 归一化权重
    topicweightsum=0
    for x in topicweights:
        topicweightsum+=x
    for i in range(0,len(topicweights)):
        topicweights[i]=topicweights[i]/topicweightsum
    # print(selftopics)
    # print(topicweights)
    num=len(topicweights)
    # 将每个主题的权重换成每个主题下应该看得新闻个数
    topic_newsnum_list=[]
    for j in range(num):
         cmd = "z%s = int(topicweights[j]*z+0.5)" % j
         # 加0.5目的是为了转换成int时四舍五入
         exec (cmd)
         topic_newsnum_list.append(eval("z%s" % j))
    for j in range(len(selftopics)):
        utilities_zj = {}
        for newid in selfchoosedic[selftopics[j]]:
            newvector = newsdic[newid]['newvector']
            new_utility = math.exp(vij_selfchoose(uservector, newvector))
            utilities_zj[newid] = new_utility
        # 计算所有新闻效度的和
        utilitysum = 0
        for value in utilities_zj.values():
            utilitysum += value
        probabilities = {}
        for newid, utility in utilities_zj.items():
            probability = utility / utilitysum
            probabilities[newid] = probability
        probabilities = sorted(probabilities.items(), key=lambda x: x[1])
        choose_new_list = []
        probability_list = []
        for i in probabilities:
            choose_new_list.append(i[0])
            probability_list.append(i[1])
        # print(choose_new_list)
        # print(probability_list)
        # 上边两行打印不要删，到时候可以看看每个推荐以及选择概率
        readedlist_zj = []
        while (len(readedlist_zj) < topic_newsnum_list[j]):
            readed_new = random_pick(choose_new_list, probability_list)
            if readed_new not in readedlist:
                readedlist_zj.append(readed_new)
                readedlist.append(readed_new)
        # print('readedlist_zj:')
        # print(readedlist_zj)
    return readedlist

#以下测试代码用来测试选择热点值的k取什么比较合适
# uservector=um.get_user()
# newsvectordic=pm.get_day_news(2)
# recommendlist=rm.cbr(uservector,newsvectordic)
# selfchoosedic=hm.get_selfchoose_dic(newsvectordic)
# hotlist=hm.get_hotnews_list(newsvectordic)
# # print(hotlist)
# iternum=10
# readedlist=choose(0,0,1,recommendlist,hotlist,selfchoosedic,uservector,newsvectordic,iternum)
# print(readedlist)







