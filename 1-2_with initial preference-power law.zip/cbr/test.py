# lists=[[1,2,3,4],[1,26]]
# for i in range(len(lists)):
#     exec("t%d=lists[i]" % i)
# print(t0)

varnames=locals()
lists=[[1,2,3,4],[1,26]]
for i in range(len(lists)):
    varnames['array'+str(i)]=lists[i]
    print(varnames['array'+str(i)])