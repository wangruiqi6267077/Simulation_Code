# 统计gini变大和变小的个数分别为多少
import pandas as pd
import matplotlib.pyplot as plt
df=pd.read_csv('result_of_experiment_1.csv')
list_up=[]
list_down=[]
list_same=[]
for i, row in df.iterrows():
    if abs(row['gini17']-row['gini18'])<=0.01:
        list_same.append(row['userid'])
    elif row['gini17']<row['gini18']:
        list_up.append(row['userid'])
    elif row['gini17']>row['gini18']:
        list_down.append(row['userid'])
    else:
        print(row['userid'])
# print("the number of up is:")
up=len(list_up)
# print('the number of down is :')
down=len(list_down)
same=len(list_same)
# 接下来对结果形成饼形图
labels='up','down','same'
sizes=[up,down,same]
colors=['green','yellow','red']
plt.pie(sizes,labels=labels,autopct='%1.1f%%',colors=colors)
plt.axis('equal')
plt.show()