dic={1:1,2:2,3:3}
dic={1:4,2:4,3:4}
print(dic)





# import user_model as um
# import platform_model as pm
# import hotnews_and_selfchoose_model as hm
# import feedback_modele as fm
# from collections import Counter
# List =[1,2,2,3,3,3,4,4,4,4,5,5,5,5,5]
# Strlist=['A','B','B','C','C','C','D','D','D','D']
# res = Counter(List)
# print(res)
# res=Counter(Strlist).most_common(9)
# for tuple in res:
#     print(tuple[0])



# user=um.get_user()
# newsdic=pm.get_day_news(1)
# selfchoosedic=hm.get_selfchoose_dic(newsdic)
# # print(selfchoosedic)
# # print(user)
# selftopics=[]
# topicweights=[]
# for n in range(0,10):
#     if user[n]>=0.15:
#         selftopics.append('topic'+str(n))
#         topicweights.append(user[n])
# if len(selftopics)==0:
#     n=user.index(max(user))
#     selftopics.append('topic'+str(n))
#     topicweights.append(1)
# # 归一化权重
# topicweightsum=0
# for x in topicweights:
#     topicweightsum+=x
# for i in range(0,len(topicweights)):
#     topicweights[i]=topicweights[i]/topicweightsum
# print(selftopics)
# print(topicweights)
# z=10
# num=len(topicweights)
# # 将每个主题的权重换成每个主题下应该看得新闻个数
# topic_newsnum_list=[]
# for j in range(num):
#      cmd = "z%s = int(topicweights[j]*z+0.5)" % j
#      # 加0.5目的是为了转换成int时四舍五入
#      exec (cmd)
#      topic_newsnum_list.append(eval("z%s" % j))
# for j in range(len(selftopics)):
#     utilities_zj = {}
#     for newid in selfchoosedic[selftopics[j]]:
#         newvector = newsdic[newid]['newvector']
#         new_utility = math.exp(vij(uservector, newvector))
#         utilities_zj[newid] = new_utility
#     # 计算所有新闻效度的和
#     utilitysum = 0
#     for value in utilities_zj.values():
#         utilitysum += value
#     probabilities = {}
#     for newid, utility in utilities_zj.items():
#         probability = utility / utilitysum
#         probabilities[newid] = probability
#     probabilities = sorted(probabilities.items(), key=lambda x: x[1])
#     choose_new_list = []
#     probability_list = []
#     for i in probabilities:
#         choose_new_list.append(i[0])
#         probability_list.append(i[1])
#     # print(choose_new_list)
#     # print(probability_list)
#     # 上边两行打印不要删，到时候可以看看每个推荐以及选择概率
#     readedlist_zj = []
#     while True:
#         readed_new = random_pick(choose_new_list, probability_list)
#         if readed_new not in readedlist:
#             readedlist_zj.append(readed_new)
#         if len(readedlist_zj) >= topic_newsnum_list[j]:
#             break
#     readedlist.append(readedlist_zj)




# print(selftopics)

# for key, values in selfchoosedic.items():
#     if key in selftopics:
#         print(values)














# def random_pick(some_list,probabilities):
#     x=random.uniform(0,1)
#     cumulative_probability=0.0
#     for item,item_probability in zip(some_list,probabilities):
#         cumulative_probability+=item_probability
#         if x < cumulative_probability:
#             break
#     return item

# newsdic={'1':[1,1,1],
#          '2':[2,2,2]}
# print(newsdic[str(1)])




# dic={'1':[1,1,1],
#      '2':[2,2,2],
#      '3':[3,3,3]}
# list1=[1,3,4]
# # for key,value in dic.items():
# #     if int(key) in list:
# #         dic.pop(key)
# # 遍历字典时不能删除元素,所以上述办法不行，换用下边，将字典的所有key放在列表中，遍历这个列表而不是字典
# for k in list(dic.keys()):
#     if int(k) in list1:
#         dic.pop(k)
# print(dic)

# dic={1:[11,1,1],
#      2:[2,2,2]}
# print(dic[1][0])
# print(dic)
# for key in dic.keys():
#     print(key)

# import pandas as pd
# df=pd.DataFrame({'userid':[],
#                  'newid':[],
#                  'day':[],
#                  'topic0':[],
#                  'topic1':[],
#                  'topic2':[],
#                  'topic3':[],
#                  'topic4':[],
#                  'topic5': [],
#                  'topic6': [],
#                  'topic7': [],
#                  'topic8': [],
#                  'topic9': [],
#               })
# print(df)
# list=[1,1,1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1]
# dfi=pd.DataFrame(list).T
# dfi.columns=df.columns
# df=df.append(dfi)
# print(df)


# def changshi(dic,list1):
#     dic1=dic
#     list2=list1
#     for k in list(dic1.keys()):
#         if int(k) in list2:
#             dic1.pop(k)
#     print(dic1)
# dic={'1':[1,1,1],
#      '2':[2,2,2],
#      '3':[3,3,3]}
# list1=[1,3,4]
# changshi(dic,list1)
# print(dic)




