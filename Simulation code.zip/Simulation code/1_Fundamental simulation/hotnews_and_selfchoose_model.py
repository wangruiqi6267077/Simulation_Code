#本模块用来从当日新闻中根据hot值排序，并形成热点列表

# 参数：热点新闻和自选列表返回新闻的个数
num_of_return_list=10

def get_hotnews_list(news_dic):
    newsdic=news_dic
    dic={}
    # 创建一个临时字典，这里边只放newid：hot值
    for newid,newinfor in newsdic.items():
        dic[newid]=newinfor['newhot']
    dic = sorted(dic.items(), key=lambda x: x[1])
    hotlist=[]
    for i in range(num_of_return_list):
        hotlist.append(dic.pop()[0])
        i+=1
    return hotlist

def get_selfchoose_dic(news_dic):
    newsdic=news_dic
    selfchoose_dic={}
    for i in range(0,num_of_return_list):
        dic={}
        for newid,newinfor in newsdic.items():
            dic[newid]=newinfor['newvector'][i]
        dic = sorted(dic.items(), key=lambda x: x[1])
        # print(dic)
        selfchooselist_i=[]
        for j in range(10):
            selfchooselist_i.append(dic.pop()[0])
            j += 1
        selfchoose_dic['topic'+str(i)]=selfchooselist_i
    return selfchoose_dic

# newsdic=pm.get_day_news(2)
# # print(newsdic)
# selfchoose_dic=get_selfchoose_dic(newsdic)
# print(selfchoose_dic)