from collections import Counter
import numpy as np
# 定义基于内容的推荐系统
# 输入用户向量，当天新闻集合字典，以及已经阅读过的新闻列表


# 参数：返回的推荐列表中包含的新闻的个数
num_of_recommendlist_news=10



def cbr(uservector,news_dic):
    uservector=np.array(uservector)
    newsdic=news_dic
    recommendedlist=[]
    new_user_distance_dic = {}
    for newid,newinform in newsdic.items():
        newvector=np.array(newinform['newvector'])
        distance=np.linalg.norm(uservector - newvector)
        new_user_distance_dic[newid] = distance
    new_user_distance_list = sorted(new_user_distance_dic.items(), key=lambda x: x[1])
    i = 0
    for x in new_user_distance_list:
        if i<num_of_recommendlist_news:
            recommendedlist.append(x[0])
            i+=1
    return recommendedlist

# 定义协同过滤推荐算法
def cfr(uservector,users_dic,all_user_read_record):
    uservector = np.array(uservector)
    similar_dic={}
    for key,value in users_dic.items():
        # 首先挑选出5个于被分析用户相似的用户
        similaruservector=np.array(value)
        distance=np.linalg.norm(uservector - similaruservector)
        similar_dic[key]=distance
    similar_list = sorted(similar_dic.items(), key=lambda x: x[1])
    similaruser=[]
    for tuple in similar_list[:5]:
        similaruser.append(tuple[0])
     # 从所有用户的浏览记录中挑选出这5个相似用户的浏览记录并且保存在字典中
    similar_read_records_list=[]
    for key ,value in all_user_read_record.items():
        if key in similaruser:
            for i in value:
                similar_read_records_list.append(i)
    res = Counter(similar_read_records_list).most_common(num_of_recommendlist_news)
    # print(res)
    resultlist=[]
    for tuple in res:
        resultlist.append(tuple[0])
    return resultlist
    #接下来挑选相似用户阅读次数最多的文章推荐给用户
#
#
# user_dic=um.get_users()
# uservector=user_dic['6']
# all_user_read_record_dic={}
# # all_user_read_record_dic={'1': ['4-33', '4-38', '4-31', '4-2', '4-42', '4-17', '4-14', '4-27', '4-37'], '2': ['4-7', '4-5', '4-2', '4-33', '4-6', '4-25'], '3': ['4-5', '4-29', '4-32', '4-2', '4-40', '4-13', '4-28', '4-25', '4-6'], '4': ['4-1', '4-47', '4-2', '4-33', '4-17', '4-42', '4-20', '4-8', '4-15'], '5': ['4-45', '4-25', '4-42', '4-2', '4-6', '4-14', '4-5']}
# list=cfr(uservector,user_dic,all_user_read_record_dic)
# print(list)


# 下边这个是原来的旧程序
def cbr_old(uservector,newsdic, pop_list,readed_list):
    # 根据用户向量，推荐新闻，但是不重复推荐，所以用readed_list来筛选，即not in
    uservector=np.array(uservector)
    uservector=np.array(uservector)
    newsdic=newsdic
    poplist=pop_list
    readedlist=readed_list
    recommendedlist=[]
    new_user_distance_dic={}
    # 按照与用户的距离对新闻排序，先计算每个新闻与用户的距离
    for newid,newvector in newsdic.items():
        newvector=np.array(newvector)
        distance=np.linalg.norm(uservector - newvector)
        new_user_distance_dic[newid]=distance
    new_user_distance_list= sorted(new_user_distance_dic.items(), key=lambda x: x[1])
    # 这里排序之后变成了列表的列表，形如[('2', 1), ('1', 3), ('3', 8)]，而不再是字典
    i=0
    for popnewid in poplist:
        if popnewid not in readedlist:
            recommendedlist.append(popnewid)
            i+=1
    for newid in new_user_distance_list:
        if int(newid[0]) not in readedlist and int(newid[0]) not in poplist and int(newid[0]) not in recommendedlist and i<8:
            recommendedlist.append(int(newid[0]))
            i+=1
    return recommendedlist

# user=um.get_user()
# print('user vector is:----------------------------')
# print(user)
# news_dic=pm.get_day_news(2)
# print('news dictionary:_________________________')
# print(news_dic)
# pop_list=pm.get_popular_news()
# # print('pop list:--------------------')
# # print(pop_list)
# readed_list=[1,11,9,6]
# recommendlist=cbr(user,news_dic)
# print('recommendlist is :--------------------')
# print(recommendlist)
