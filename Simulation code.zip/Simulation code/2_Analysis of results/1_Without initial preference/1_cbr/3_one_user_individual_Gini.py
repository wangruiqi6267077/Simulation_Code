import pandas as pd
import numpy as np
import matplotlib.pyplot as pl
def Gini(topic_weights_list):
    topic_weights=topic_weights_list
    cum_weights = np.cumsum(sorted(np.append(topic_weights, 0)))
    sum_weights = cum_weights[-1]
    xarray1 = np.array(range(0, len(cum_weights))) / np.float(len(cum_weights) - 1)
    # upper = xarray1
    yarray1 = cum_weights / sum_weights
    B = np.trapz(yarray1, x=xarray1)
    A = 0.5 - B
    G = A / (A + B)
    return 1-G
def pic(list):
    xarray = [i for i in range(1, len(list) + 1, 1)]
    yarray = list
    pl.plot(xarray, yarray, c='red')
    pl.show()
df=pd.read_csv('users_news_datas_(0, 0, 1).csv')
dfi=df.loc[df['userid']==30]
ginilisti=[]
grouped=dfi.groupby(df['day'])
dfnew=grouped.sum()/grouped.count()
whole_gini_list=[]
for i ,row in dfnew.iterrows():
    list=[]
    for j in range(10):
        list.append(row['topic'+str(j)])
    whole_gini_list.append(list)#形成列表的列表，内部列表是某一天的topic列表
    # print(whole_gini_list)
resultlist=[]
i=1
for daylist in whole_gini_list:
    if i%1==0:#调节可视化曲线的密度，每个点画一次还是每两个点画一次
        daygini=Gini(daylist)
            # print(daygini)
        resultlist.append(daygini)
        i+=1
    else:
        i+=1
for i in resultlist:
    print(i)
pic(resultlist)