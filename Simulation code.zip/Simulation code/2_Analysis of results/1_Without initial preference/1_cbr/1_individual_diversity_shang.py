import pandas as pd
import numpy as np
import matplotlib.pyplot as pl

def pic(list):
    xarray = [i for i in range(1, len(list) + 1, 1)]
    yarray = list
    pl.plot(xarray, yarray, c='red')
    # pl.show()

def Shang(topic_weights_list):
    ent=0.0
    for x in topic_weights_list:
        p=x
        logp=np.log2(p)
        ent-=p*logp
    return ent
def get_users_shanglist_or_user_shanglist(df):
    #这个函数是从dataframe中得到每个用户每天的gini系数列表，或者得到每天的所有用户平均gini系数列表
    shanglist=[]
    for userid in range(1,51):
        dfi=df.loc[df['userid']==userid]
        # print(dfi)
        shanglisti=[]
        for index,row in dfi.iterrows():
            uservector=[]
            for i in range(10):
                uservector.append(row['topic'+str(i)])
            shangrow=Shang(uservector)
            shanglisti.append(shangrow)
        shanglist.append(shanglisti)
    # pic(ginilisti)#将每个用户的gini系数随时间变化都画出来
    return shanglist#返回的是所有用户所有天的gini系数，为列表的列表
def average_users_shang_pic(shanglist):
    # 将所有用户每天的平均gini随day变化画出来
    avelist=[]
    for day in range(0,len(shanglist[0])):
        dayshang=0
        for usershang in shanglist:
            dayshang+=usershang[day]
        dayshang=dayshang/50
        avelist.append(dayshang)
        # print(daygini)
    pic(avelist)
    return avelist

def muti_case_in_one_case(*shanglists):
    xarray=[i for i in range(1, len(shanglists[0]) + 1, 1)]
    varnames = locals()
    for i in range(len(shanglists)):
        varnames['array' + str(i)] = shanglists[i]
        pl.plot(xarray,varnames['array' + str(i)],label='array' + str(i))
    pl.legend()
    pl.xlabel('Day')
    pl.ylabel('Average Individual  Entropy')
    pl.show()

df1=pd.read_csv('userprofile_datas_(1, 0, 0).csv')
shanglist1=get_users_shanglist_or_user_shanglist(df1)
averagelist1=average_users_shang_pic(shanglist1)

df2=pd.read_csv('userprofile_datas_(0, 1, 0).csv')
shanglist2=get_users_shanglist_or_user_shanglist(df2)
averagelist2=average_users_shang_pic(shanglist2)

df3=pd.read_csv('userprofile_datas_(0, 0, 1).csv')
shanglist3=get_users_shanglist_or_user_shanglist(df3)
averagelist3=average_users_shang_pic(shanglist3)

muti_case_in_one_case(averagelist1,averagelist2,averagelist3)