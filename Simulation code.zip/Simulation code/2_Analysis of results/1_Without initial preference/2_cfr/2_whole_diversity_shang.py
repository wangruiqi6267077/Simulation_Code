import pandas as pd
import numpy as np
import matplotlib.pyplot as pl

def pic(list):
    xarray = [i for i in range(1, len(list) + 1, 1)]
    yarray = list
    pl.plot(xarray, yarray, c='red')
    # pl.show()
def muti_case_in_one_pic(*shanglists):
    xarray=[i for i in range(1, len(shanglists[0]) + 1, 1)]
    varnames = locals()
    for i in range(len(shanglists)):
        varnames['array' + str(i)] = shanglists[i]
        pl.plot(xarray,varnames['array' + str(i)],label='array' + str(i))
    pl.legend()
    pl.xlabel('Day')
    pl.ylabel('Average Aggregate  Entropy')
    pl.show()
def Shang(topic_weights_list):
    ent=0.0
    for x in topic_weights_list:
        p=x
        logp=np.log2(p)
        ent-=p*logp
    return ent
def get_agg_shang(df):
    grouped=df.groupby(df['day'])
    dfnew=grouped.sum()/grouped.count()
    whole_shang_list=[]
    for i ,row in dfnew.iterrows():
        list=[]
        for j in range(10):
            list.append(row['topic'+str(j)])
        whole_shang_list.append(list)#形成列表的列表，内部列表是某一天的topic列表
    # print(whole_shang_list)
    resultlist=[]
    i=1
    for daylist in whole_shang_list:
        if i%2==0:#调节可视化曲线的密度，每个点画一次还是每两个点画一次
            dayshang=Shang(daylist)
            print(dayshang)
            resultlist.append(dayshang)
            i+=1
        else:
            i+=1
    return resultlist#返回该user_news文件中形成的整体多样性gini随时的列表
print('______________仅推荐____________________')
df1=pd.read_csv('users_news_datas_(1, 0, 0).csv')
aggshanglist1=get_agg_shang(df1)
for i in aggshanglist1:
    print(i)
print('______________仅热点____________________')
df2=pd.read_csv('users_news_datas_(0, 1, 0).csv')
aggshanglist2=get_agg_shang(df2)
for i in aggshanglist2:
    print(i)
print('______________仅自选____________________')
df3=pd.read_csv('users_news_datas_(0, 0, 1).csv')
aggshanglist3=get_agg_shang(df3)
for i in aggshanglist3:
    print(i)
muti_case_in_one_pic(aggshanglist1,aggshanglist2,aggshanglist3)