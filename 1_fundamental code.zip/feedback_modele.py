def userupdata(uservector,readedlist,newsdic):
     add_list=[]
     num=len(readedlist)
     for i in range(0,10):
         topicsum=0
         for readed_new in readedlist:
             topicsum+=newsdic[readed_new]['newvector'][i]
         add_list.append(topicsum/num)
     uservector_new=[]
     for j in range(0,10):
         newusertopic=0.9*uservector[j]+0.1*add_list[j]
         uservector_new.append(newusertopic)
     return uservector_new

# uservector=um.get_user()
# newsdic=pm.get_day_news(2)
# readed_list=['2-1','2-2','2-3','2-8','2-19','2-40']
# new_uservector=userupdata(uservector,readed_list,newsdic)
# print(uservector)
# print(new_uservector)